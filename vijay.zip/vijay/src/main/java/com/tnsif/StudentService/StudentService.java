package com.tnsif.StudentService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class StudentService {

	@Autowired
	private StudentRepository repo;
	
	//Insert the record into the database
	public void insertRecord(Student cust)
	{
		repo.save(cust);
	}
	
	//Get all the records from the table
	public List<Student> listAllRecords()
	{
		return repo.findAll();
	}
	
	//Retrieving the particular record
	public Student getParticularRecord(Integer id)
	{
		return repo.findById(id).get();
	}
	
	//Deleting the record method
	public void delete(Integer id)
	{
		repo.deleteById(id);
	}
	
	//Update the record
	public void update(Student updatedStudent) {
	    if(repo.existsById(updatedStudent.getSid())) {	        
	        Student existingStudent = repo.findById(updatedStudent.getSid()).get();
	        existingStudent.setSname(updatedStudent.getSname());
	        existingStudent.setCity(updatedStudent.getCity());
	        repo.save(existingStudent);
	    } else {
	        
	        System.out.println("Student with ID " + updatedStudent .getSid() + " not found. Cannot update.");
	    }
	}

	
	
	
}
